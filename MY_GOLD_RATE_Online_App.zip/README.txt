MY GOLD RATE — Online app starter

Files:
- index.html: responsive Gujarati gold calculator
- manifest.webmanifest + sw.js: installable PWA support

How to publish:
1. Upload all three files to a static HTTPS host (GitHub Pages, Netlify, or your own hosting).
2. Open the published HTTPS URL on Android Chrome.
3. Choose browser menu > Install app / Add to Home screen.

Live-rate behavior:
- Gold API endpoint: https://gold-api.com/price/XAU
- USD/INR endpoint: https://open.er-api.com/v6/latest/USD
Live API availability, CORS, response format, rate limits, and provider terms can change. If live fetching fails, use Manual Rate mode or enter the two rates yourself.

Important:
This is an indicative calculator, not a certified market quote. Import duty is editable and the default is only a placeholder; verify the applicable Indian customs rate before relying on it. It excludes jeweller margin, making charges, wastage, and other local costs.
For a true public app, use a backend proxy/API key where required, configure a custom domain, privacy policy, and test live data before launch.
